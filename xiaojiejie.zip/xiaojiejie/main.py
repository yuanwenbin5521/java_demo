from selenium import webdriver
from browsermobproxy import Server
import time
import m83udownload
import os
import threading
import sys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait

def download(path, name, url):
    file_name = "***"
    m83udownload.main(url, os.path.join(os.path.join(path, name + "_tmp")), file_name=file_name, worker_num=20, ts_timeout=120)
    filelist = os.listdir(os.path.join(path, name + "_tmp"))
    filelist.sort()
    newfile = open(os.path.join(path, name + ".mp4"), 'wb')
    for item in filelist:
        for txt in open(os.path.join(os.path.join(path, name + "_tmp"), item), 'rb'):
            newfile.write(txt)
    newfile.close()


server = Server(r'E:\browsermob-proxy-2.1.4\bin\browsermob-proxy.bat')
server.start()
proxy = server.create_proxy()
proxy.new_har("1111mod", options={'captureHeaders': True, 'captureContent': True})

chrome_options = Options()

chrome_options.add_argument('--ignore-certificate-errors')
chrome_options.add_argument('--proxy-server={0}'.format(proxy.proxy))
desired_capabilities = DesiredCapabilities.CHROME  # 修改页面加载策略
desired_capabilities["pageLoadStrategy"] = "none"  # 注释这两行会导致最后输出结果的延迟，即等待页面加载完成再输出


driver = webdriver.Chrome(chrome_options=chrome_options)


wait = WebDriverWait(driver, 10)  #后面可以使用wait对特定元素进行等待
base_url = "https://1111mod.net/index.php/vod/type/id/101/page/"


path = str(sys.argv[1])
getDate = ""
# 获取视频地址
index = 1
while True:
    driver.get(base_url + str(index) + ".html")
    index=index+1
    videoInfo = driver.find_elements_by_css_selector(".entry-title a")
    if videoInfo:
        for info in videoInfo:
            name = info.text
            # date = driver.find_element_by_css_selector(".entry-title").text.replace(" ", "").replace("/", "")
            # if date != getDate:
            #     break
            if not os.path.exists(os.path.join(path, name + ".mp4")):
                driverTmp=webdriver.Chrome(chrome_options=chrome_options)
                driverTmp.get(info.get_attribute("href"))
                result = proxy.har
                for entry in result['log']['entries']:
                    _url = entry['request']['url']
                    if "index.m3u8" in _url:
                        print("start download {},{}", name, path)
                        download(path, name, _url)
                        driverTmp.quit()
    else:
        break
server.stop()
driver.quit()
# driver = webdriver.Chrome()    # Chrome浏览器
#
# driver.get("https://1111mod.net/index.php/vod/type/id/101/page/1.html")
# elements=driver.find_elements_by_css_selector(".entry-title a")
# for e in elements:
#     print(e.get_attribute("href"))
#
# driver.close()
